import "dart:convert";

import "package:http/http.dart" as http;

import "models.dart";

class StokkuApi {
  StokkuApi({
    String? baseUrl,
    http.Client? client,
  })  : baseUrl = baseUrl ??
            const String.fromEnvironment(
              "STOKKU_API_URL",
              defaultValue: "http://10.0.2.2:8080/api",
            ),
        _client = client ?? http.Client();

  final String baseUrl;
  final http.Client _client;

  Future<List<Product>> getProducts() async {
    final response = await _client.get(Uri.parse("$baseUrl/products"));
    _ensureSuccess(response);
    final data = jsonDecode(response.body) as List<dynamic>;
    return data
        .map((item) => Product.fromJson(item as Map<String, dynamic>))
        .toList();
  }

  Future<Map<String, dynamic>> createInvoice(InvoiceInput input) async {
    final response = await _client.post(
      Uri.parse("$baseUrl/invoices"),
      headers: const {
        "content-type": "application/json",
        "x-stokku-role": "admin",
      },
      body: jsonEncode(input.toJson()),
    );
    _ensureSuccess(response);
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  Future<List<dynamic>> getInvoiceComments(int invoiceId, {required String role}) async {
    final response = await _client.get(
      Uri.parse("$baseUrl/invoices/$invoiceId/comments"),
      headers: {"x-stokku-role": role},
    );
    _ensureSuccess(response);
    return jsonDecode(response.body) as List<dynamic>;
  }

  Future<Map<String, dynamic>> addInvoiceComment(int invoiceId, String message) async {
    final response = await _client.post(
      Uri.parse("$baseUrl/invoices/$invoiceId/comments"),
      headers: const {
        "content-type": "application/json",
        "x-stokku-role": "manager",
      },
      body: jsonEncode({"actor": "Budi Santoso", "message": message}),
    );
    _ensureSuccess(response);
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> getProfitStatistics({
    required String period,
  }) async {
    final selectedPeriod = period == "month" ? "month" : "week";
    final response = await _client.get(
      Uri.parse("$baseUrl/statistics/profit?period=$selectedPeriod"),
      headers: const {"x-stokku-role": "manager"},
    );
    _ensureSuccess(response);
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  void close() => _client.close();

  void _ensureSuccess(http.Response response) {
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw StokkuApiException(response.statusCode, response.body);
    }
  }
}

class StokkuApiException implements Exception {
  const StokkuApiException(this.statusCode, this.message);

  final int statusCode;
  final String message;

  @override
  String toString() => "StokkuApiException($statusCode): $message";
}
