class Product {
  const Product({
    required this.id,
    required this.name,
    required this.sku,
    required this.price,
    required this.stock,
  });

  final int id;
  final String name;
  final String sku;
  final int price;
  final int stock;

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json["id"] as int,
        name: json["name"] as String,
        sku: json["sku"] as String,
        price: json["price"] as int,
        stock: json["stock"] as int,
      );
}

class InvoiceLineInput {
  const InvoiceLineInput({required this.productId, required this.quantity});

  final int productId;
  final int quantity;

  Map<String, dynamic> toJson() => {
        "productId": productId,
        "quantity": quantity,
      };
}

class InvoiceInput {
  const InvoiceInput({
    required this.customer,
    required this.contact,
    required this.paymentType,
    required this.lines,
    this.dueDate,
  });

  final String customer;
  final String contact;
  final String paymentType;
  final String? dueDate;
  final List<InvoiceLineInput> lines;

  Map<String, dynamic> toJson() => {
        "customer": customer,
        "contact": contact,
        "paymentType": paymentType,
        "dueDate": dueDate,
        "lines": lines.map((line) => line.toJson()).toList(),
      };
}
